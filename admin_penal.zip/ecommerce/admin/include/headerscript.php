<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
<!-- css link -->
<link rel="stylesheet" href="asset/css/style.css">
  <!-- Font Awesome -->
<link rel="stylesheet" href="asset/plugins/fontawesome-free/css/all.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
  <!-- Ekko Lightbox -->
<link rel="stylesheet" href="asset/plugins/ekko-lightbox/ekko-lightbox.css">
  <!-- Theme style -->
<link rel="stylesheet" href="asset/dist/css/adminlte.min.css">
<!-- DataTables -->
<link rel="stylesheet" href="asset/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="asset/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
<link rel="stylesheet" href="asset/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
<link rel="stylesheet" href="asset/plugins/datatables/css/buttons.dataTables.min.css">
<!-- toster -->
<link rel="stylesheet" href="asset/plugins/toastr/toastr.min.css">
<link rel="stylesheet" href="asset/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="asset/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
<link rel="stylesheet" href="asset/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
<link rel="stylesheet" href="asset/plugins/datatables/css/dataTables.dateTime.min.css">
<link rel="stylesheet" href="asset/plugins/toastr/toastr.min.css">
<!-- iCheck for checkboxes and radio inputs -->
<link rel="stylesheet" href="asset/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
<!-- daterange picker -->
<!-- <link rel="stylesheet" href="asset/plugins/daterangepicker/daterangepicker.css"> -->
<!-- <link href="asset/plugins/css/bootstrap-datepicker.min.css" rel="stylesheet"/> -->
<!--------- confirmation alert ----------->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
<!-- select2 -->
<link href="asset/dist/css/select2.min.css" rel="stylesheet" />

<!-- select2-bootstrap4-theme -->
<link href="asset/dist/css/select2-bootstrap4.css" rel="stylesheet">
<!-- -------------Jquery Lightbox--------- -->
<link rel="stylesheet" href="asset/plugins/lightbox/jquery.fancybox.min.css" type="text/css" media="screen" />
<link rel="stylesheet" href="asset/plugins/daterangepicker/daterangepicker.css">  
<!-- Ionicons -->
<!-- <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css"> -->
<!-- <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css"> -->
