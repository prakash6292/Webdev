<?php
  if(!isset($_SESSION["user_id"])){
      header('location:login.php');
      exit;
  }
?>
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
  <!-- Left navbar links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
    </li>
    <li class="nav-item d-none d-sm-inline-block">
      <!-- <a href="../index3.html" class="nav-link">Home</a> -->
    </li>
    <li class="nav-item d-none d-sm-inline-block">
      <!-- <a href="#" class="nav-link">Contact</a> -->
    </li>
  </ul>

  <!-- Right navbar links -->
  <ul class="navbar-nav ml-auto">
    <li class="nav-item">
      <a href="logout.php" class="btn btn-primary mr-3" href="#" role="button">
        Logout
      </a>
    </li>
  </ul>
</nav>
<?php 
  require_once 'sidebar.php'; 
?>